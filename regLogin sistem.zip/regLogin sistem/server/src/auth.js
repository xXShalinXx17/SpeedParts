import jwt from "jsonwebtoken";

export function createToken(user) {
    return jwt.sign({
        sub: user.id,
        email: user.email,
        role: user.role
    },
    process.env.JWT_SECRET,
    {expiresIn: "2h"}
    );
}

export function requireAuth(req, res, next) {
    const header = req.headers.authorization;

    if (!header?.startsWith("Bearer ")) {
        return res.status(401).json({message: "No autenticado."});
    }

    const token = header.slice("Bearer ".length);

    try {
        req.auth = jwt.verify(token, process.env.JWT_SECRET);
        next();
    }

    catch {
        return res.status(401).json({message: "Token inválido o expirado."});
    }
}