import "dotenv/config";
import express from "express";
import cors from "cors";
import authRoutes from "./routes/auth.routes.js";
import "./db.js";

const app = express();
const PORT = Number(process.env.PORT || 3001);

if (!process.env.JWT_SECRET) {
    throw new Error("JWT_SECRET no está configurado en server/.env");
}

app.use(cors({
    origin: process.env.CLIENT_ORIGIN || "http://localhost:5173"
}));

app.use(express.json({limit: "20kb"}));
app.get("/api/health", (_req, res) => {
    res.json({ok: true, service: "empresa-auth-api"});
});

app.use("/api/auth", authRoutes);
app.use((_req, res) => {
    res.status(404).json({message: "Endpoint no encontrado."});
});

app.listen(PORT, () => {
    console.log(`API ejecutándose en http://localhost:${PORT}`);
});
