import {Router} from "express";
import bcrypt from "bcryptjs";
import db from "../db.js";
import {createToken, requireAuth} from "../auth.js";

const router = Router();

function normalizeEmail(email) {
    return String(email || "").trim().toLowerCase();
}

function publicUser(user) {
    return {
        id: user.id,
        email: user.email,
        role: user.role,
        createdAt: user.created_at
    };
}

router.post("/register", async (req, res) => {
    try {
        const email = normalizeEmail(req.body.email);
        const password = String(req.body.password || "");

        if (!email || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
            return res.status(400).json({ message: "Introduce un email válido." });
        }

        if (password.length < 8) {
            return res.status(400).json({
                message: "La contraseña debe tener al menos 8 caracteres."
            });
        }

        const existing = db
        .prepare("SELECT id FROM users WHERE email = ?")
        .get(email);

        if (existing) {
            return res.status(409).json({
                message: "Ya existe una cuenta con este email."
            });
        }

        //by the way, the employee password only exists on the server (in ".env")
        const isEmployee = process.env.EMPLOYEE_PASSWORD && password === process.env.EMPLOYEE_PASSWORD;
        const role = isEmployee ? "empleado" : "usuario";
        const passwordHash = await bcrypt.hash(password, 12);
        const result = db
            .prepare(`INSERT INTO users (email, password_hash, role) VALUES (?, ?, ?)`)
            .run(email, passwordHash, role);

        const user = db
            .prepare("SELECT * FROM users WHERE id = ?")
            .get(result.lastInsertRowid);

        const token = createToken(user);
        return res.status(201).json({
            message: "Cuenta creada correctamente.",
            token,
            user: publicUser(user)
        });
    }
    catch (error) {
        console.error(error);
        return res.status(500).json({ message: "Error interno del servidor." });
    }
});

router.post("/login", async (req, res) => {
    try {
        const email = normalizeEmail(req.body.email);
        const password = String(req.body.password || "");

        const user = db
            .prepare("SELECT * FROM users WHERE email = ?")
            .get(email);

            if (!user) {
                return res.status(401).json({ message: "Email o contraseña incorrectos." });
            }

            const validPassword = await bcrypt.compare(password, user.password_hash);
                if (!validPassword) {
                    return res.status(401).json({ message: "Email o contraseña incorrectos." });
                }

            const token = createToken(user);
                return res.json({
                    message: "Inicio de sesión correcto.",
                    token,
                    user: publicUser(user)
                });
    }
    catch (error) {
        console.error(error);
        return res.status(500).json({ message: "Error interno del servidor." });
    }
});

router.get("/me", requireAuth, (req, res) => {
    const user = db
        .prepare("SELECT * FROM users WHERE id = ?")
        .get(req.auth.sub);

        if (!user) {
            return res.status(404).json({ message: "Usuario no encontrado." });
        }
    res.json({ user: publicUser(user) });
});

router.post("/logout", (_req, res) => {
    res.json({
        message: "Logout procesado. El cliente debe eliminar el token."
    });
});
export default router;