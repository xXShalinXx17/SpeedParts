import React, {useEffect, useState} from "react";
import {getMe, login, logout, register} from "./api";

const TOKEN_KEY = "empresa_auth_token";

function validate(email, password, mode) {
    if (!email.trim()) return "Introduce tu correo electrónico.";
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
        return "Introduce un correo electrónico válido.";
    }

    if (!password) return "Introduce tu contraseña.";

    if (mode === "register" && password.length < 8) {
        return "La contraseña debe tener al menos 8 caracteres.";
    }

    return "";
}

export default function App() {
    const [mode, setMode] = useState("login");
    const [email, setEmail] = useState("");
    const [password, setPassword] = useState("");
    const [showPassword, setShowPassword] = useState(false);
    const [loading, setLoading] = useState(false);
    const [message, setMessage] = useState("");
    const [error, setError] = useState("");
    const [user, setUser] = useState(null);

    useEffect(() => {
        const token = localStorage.getItem(TOKEN_KEY);
        if (!token) return;

        getMe(token)
        .then((data) => setUser(data.user))
        .catch(() => localStorage.removeItem(TOKEN_KEY));
    }, []);

    function switchMode(nextMode) {
        setMode(nextMode);
        setError("");
        setMessage("");
        setPassword("");
    }

    async function handleSubmit(event) {
        event.preventDefault();

        const validationError = validate(email, password, mode);
        if (validationError) {
            setError(validationError);
            return;
        }

        setLoading(true);
        setError("");
        setMessage("");

        try {
            const data = mode === "login" ? await login(email, password) : await register(email, password);
            localStorage.setItem(TOKEN_KEY, data.token);
            setUser(data.user);
            setPassword("");
            setMessage(data.message);
        }

        catch (err) {
            setError(err.message);
        } 
    
        finally {
            setLoading(false);
        }
    }

    async function handleLogout() {
        const token = localStorage.getItem(TOKEN_KEY);

        try {
            if (token) await logout(token);
        } 

        catch {} 
        finally {
            localStorage.removeItem(TOKEN_KEY);
            setUser(null);
            setMessage("");
            setError("");
        }
    }

    if (user) {
        return (
            <main className="page">
                <section className="card dashboard">
                    <div className="brand">EMPRESA</div>
                    <span className="status">Sesión activa</span>

                    <h1>Bienvenido</h1>
                    <p className="subtitle">{user.email}</p>

                    <div className="profile">
                        <div>
                            <span className="label">ID</span>
                            <strong>#{user.id}</strong>
                        </div>
                        <div>
                            <span className="label">Rol</span>
                            <strong>{user.role}</strong>
                        </div>
                    </div>

                    <button className="button" onClick={handleLogout}>Cerrar sesión</button>
                </section>
            </main>
        );
    }

    return (
        <main className="page">
            <section className="card">
                <div className="brand">EMPRESA</div>

                <div className="heading">
                    <h1>{mode === "login" ? "Iniciar sesión" : "Crear cuenta"}</h1>
                    <p> {
                        mode === "login" ? "Accede con tu correo y contraseña." : "Crea una cuenta para acceder al sistema."
                    } 
                    </p>
                </div>

                <div className="tabs" role="tablist">
                    <button className={mode === "login" ? "tab active" : "tab"} onClick={() => switchMode("login")} type="button">Iniciar sesión</button>
                    <button className={mode === "register" ? "tab active" : "tab"} onClick={() => switchMode("register")} type="button">Registrarse</button>
                </div>

                <form onSubmit={handleSubmit} noValidate>
                    <label htmlFor="email">Correo electrónico</label>
                    <input
                        id="email"
                        type="email"
                        autoComplete="email"
                        placeholder="nombre@empresa.com"
                        value={email}
                        onChange={(e) => setEmail(e.target.value)}
                        disabled={loading}
                    />

                    <label htmlFor="password">Contraseña</label>
                    <div className="password-wrap">
                        <input
                            id="password"
                            type={showPassword ? "text" : "password"}
                            autoComplete={mode === "login" ? "current-password" : "new-password"}
                            placeholder="••••••••"
                            value={password}
                            onChange={(e) => setPassword(e.target.value)}
                            disabled={loading}
                        />
                        <button
                            type="button"
                            className="show-password"
                            onClick={() => setShowPassword((value) => !value)}
                            aria-label={showPassword ? "Ocultar contraseña" : "Mostrar contraseña"}
                        >{showPassword ? "Ocultar" : "Mostrar"}</button>
                    </div>

                    {mode === "register" && (
                        <p className="hint">Los empleados de la empresa deben utilizar la contraseña predefinida para que el sistema pueda asignar automáticamente el rol de empleado.</p>
                    )}
                    {error && <div className="alert error">{error}</div>}
                    {message && <div className="alert success">{message}</div>}
                    <button className="button" disabled={loading}>{loading ? "Procesando..." : mode === "login" ? "Entrar" : "Crear cuenta"}</button>
                </form>

                <p className="security">La contraseña de empleado se valida exclusivamente en el servidor.</p>
            </section>
        </main>
    );
}